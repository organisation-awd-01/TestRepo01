// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

export const EnvIdVariableName = "environment-id";
