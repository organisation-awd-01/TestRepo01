// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

export const mockEnvironmentUrl = "https://contoso.crm.dynamics.com/";
