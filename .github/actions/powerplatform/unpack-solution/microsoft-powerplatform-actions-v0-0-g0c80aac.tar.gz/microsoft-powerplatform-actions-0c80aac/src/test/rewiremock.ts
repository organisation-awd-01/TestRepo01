import rewiremock from "rewiremock";
rewiremock.overrideEntryPoint(module);
export default rewiremock;
